var nota1 =parseInt(prompt("Insira a nota 1")); //parse = converter
var nota2 =parseInt(prompt("Insira a nota 2"));
var nota3 =parseInt(prompt("Insira a nota 3"));
var media = (nota1 + nota2 + nota3) /3;
media = media.toFixed(2); //para fixar # de decimais
var nome = prompt ("Diga seu nome?");
var publicarNome = document.getElementsByClassName("nome")[0];
var publicarNota = document.getElementById("media-final");
publicarNome.innerHTML = nome;
publicarNota.innerHTML = media;

//publicar.innerHTML = "<p class='nome'>"+media+"</p>";//faz conversar com o HTML

//document.write(media); //para exibir o resultado
